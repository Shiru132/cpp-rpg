#include "../include/Character.h"
#include <iostream>
#include "../include/Monster.h"

Character::Character(const std::string &name, int hp, int defense, int damage)
{
    this->name = name;
    this->hp = hp;
    this->defense = defense;
    this->damage = damage;
}

void Character::checkMaxHP()
{
    if (hp > maxHp)
    {
        hp = maxHp;
    }
}
void Character::receiveDamage(int amount)
{
    int finalAmount = (amount - defense);
    if (finalAmount < 0)
    {
        finalAmount = 0;
    }
    std::cout << "Potwor cie uderzyl za: " << finalAmount << " obrazen" << std::endl;
    hp -= (finalAmount);
    if (hp < 0)
    {
        hp = 0;
        std::cout << "Zostales pokonany!" << std::endl;
    }
    std::cout << "Zostalo ci: " << hp << " hp" << std::endl;
}
// w klasach trzeba przypisać to do zmiennej
int Character::checkFinalAmountFromMonster(Monster *cel)
{

    int finalAmount = ((damage) - cel->getDefense());
    if (finalAmount < 0)
    {
        finalAmount = 0;
    }
    return finalAmount;
}
int Character::checkHeroHp()
{
    return hp;
}