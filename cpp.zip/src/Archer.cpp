#include "../include/Archer.h"
#include <iostream>
#include "../include/Character.h"
#include "../include/Monster.h"

Archer::Archer(const std::string &name, int hp, int defense, int damage)
    : Character(name, hp, defense, damage)
{
}
// do zrobienia coś z tym bo akutalnie robią to samo prócz mnożnika
void Archer::baseAttack(Monster*cel){
    std::cout << "Strzelasz strzala, potwor dostal: " << checkFinalAmountFromMonster(cel)*2 << " obrazen" << std::endl;
    cel->receiveBasicAttackDmg(checkFinalAmountFromMonster(cel)*2);

}
void Archer::skillAttack(Monster*cel){
    std::cout << "strzelasz ognista strzala i potwor otrzymuje: " << checkFinalAmountFromMonster(cel)*6 << " obrazen" << std::endl;
    cel->receiveSkillAttackDmg(checkFinalAmountFromMonster(cel)*6);

}

void Archer::heal() 
{
        std::cout << "Hp przed leczeniem: " << hp << std::endl;

        hp += 100;
        checkMaxHP();
        std::cout << "Teraz twoje hp wynosi:" << hp << " Hp" << std::endl;
    }

void Archer::showInfo() 
    {
        std::cout << "Nick: " << name << std::endl
                  << "Hp: " << hp << std::endl
                  << "Def: " << defense << std::endl
                  << "Dmg: " << damage << std::endl;
    }